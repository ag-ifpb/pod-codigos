public class Aluno {
    //Nome
    private String nome;
    //Nomes dos pais
    private String nomeDosPais;
    //Sexo
    private String sexo;
    //Data Nascimento
    private String dataNascimento;
    //Contato
    private String contato;
    //Endereço
    private String endereco;
    //Matricula
    private String matricula;
    //Curso
    private Curso curso;
    
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getNomeDosPais() {
		return nomeDosPais;
	}
	
	public void setNomeDosPais(String nomeDosPais) {
		this.nomeDosPais = nomeDosPais;
	}
	
	public String getSexo() {
		return sexo;
	}
	
	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	
	public String getDataNascimento() {
		return dataNascimento;
	}
	
	public void setDataNascimento(String dataNascimento) {
		this.dataNascimento = dataNascimento;
	}
	
	public String getContato() {
		return contato;
	}
	
	public void setContato(String contato) {
		this.contato = contato;
	}
	
	public String getEndereco() {
		return endereco;
	}
	
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	
	public String getMatricula() {
		return matricula;
	}
	
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	
	public Curso getCurso() {
		return curso;
	}
	
	public void setCurso(Curso curso) {
		this.curso = curso;
	}
    
    
}